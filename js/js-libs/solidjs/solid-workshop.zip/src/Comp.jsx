export default () => {
  return <h2>Child component</h2>;
};

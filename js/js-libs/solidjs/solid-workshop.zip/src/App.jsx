
import Comp from './Comp';

const App = () => {
  return (
    <>
      <h1>Hello world!!!!</h1>
      <Comp />
    </>
  );
};

export default App;

# Select Combobox Vanilla Typescript

A Pen created on CodePen.io. Original URL: [https://codepen.io/engtuncay/pen/dyxaYGr](https://codepen.io/engtuncay/pen/dyxaYGr).

Combobox patterns user-tested for accessibility, with read-only (i.e. no text input), editable, and multi-select variants.
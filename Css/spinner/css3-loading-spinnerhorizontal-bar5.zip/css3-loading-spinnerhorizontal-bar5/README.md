# CSS3 Loading Spinner - Horizontal Bar - *5

A Pen created on CodePen.

Original URL: [https://codepen.io/engtuncay/pen/bNVqQqO](https://codepen.io/engtuncay/pen/bNVqQqO).

Some css3 loading animations experiments.
Have fun and remember to share what you learn :)
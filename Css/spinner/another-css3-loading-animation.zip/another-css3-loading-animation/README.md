# Another CSS3 loading animation

A Pen created on CodePen.

Original URL: [https://codepen.io/engtuncay/pen/bNVqQRz](https://codepen.io/engtuncay/pen/bNVqQRz).

inspired by http://codepen.io/neoberg/pen/kavnF